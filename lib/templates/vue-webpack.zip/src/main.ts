import { createApp } from 'vue'
import App from './App.vue'

import './main.css'
import './index.less'

createApp(App).mount('#app')
