

## 简介（Introduction)

简易版 react+webpack配置模版

## 技术栈（Scheme）

react + typescript + webpack5

### 安装依赖

```
npm i

or

yarn
```

### 构建模式

```
npm run dev

or

yarn dev
```

### 打包

```
npm run build

or

yarn build
```